# Validation — 0.2.0 test build

Tested on 2026-10-02. These results establish software behavior, not a measured
match to a WR-T820B or to the referenced compressor circuitry.

| Check | Result |
|---|---|
| Independent DSP tests | PASS, 1,807,831 assertions across 44.1/48/96/192 kHz |
| Complete processor tests | PASS, 811,885 assertions; mono/stereo, quality changes, arbitrary block lengths, ceiling, state recall, extreme settings |
| Allocations during processing | Zero in the instrumented native processor, including quality transitions and host bypass; C++ allocation plus malloc/calloc/realloc tracked |
| Actual impulse latency | PASS, all four rates and all qualities; peak within one sample of reported latency |
| Host bypass latency/gain | PASS, exact reported delay and unity gain |
| Native VST3 host interfaces | PASS, 744,541 assertions: factory, component/controller creation, parameters, mono/stereo processing, latency and state roundtrip |
| VST3 editor objects | Both created with valid dimensions; window attachment skipped because headless display access is unavailable |
| GUI rendering | Both implemented editors rendered to PNG, inspected and corrected; these are screenshots of working components |
| Windows x64 binaries | Build PASS; PE32+ x86-64 DLLs; `GetPluginFactory`, `InitDll`, `ExitDll` exported; imports inspected |
| Windows runtime/DAW test | NOT RUN. Wine's local IPC socket was blocked. FL Studio/Mixbus scanning, live GUI, offline bounce and bridges await user testing |
| Cross-plugin global settings | Native same-process processor checks PASS. Windows named shared-memory implementation compiled; cross-DLL runtime test NOT RUN |
| Full console factory/hardware comparison | NOT RUN; reference model gates remain unresolved, see MODEL-STATUS.md |

Reported latency (quality-independent):

| Host rate | Channel | Master |
|---|---:|---:|
| 44.1 kHz | 67 samples | 200 samples |
| 48 kHz | 67 samples | 211 samples |
| 96 kHz | 67 samples | 355 samples |
| 192 kHz | 67 samples | 643 samples |

## Overload alias benchmark

Master Soft Clip; 48 kHz; coherent 10986.328125 Hz sine at 0.7 peak, +18 dB drive,
noise OFF. First 65,536 samples discarded, next 65,536 analyzed with an unwindowed
coherent FFT. DC and valid harmonics through Nyquist were excluded from the
nonharmonic-spur search. This intentionally exceeds normal operation.

| Quality | Largest nonharmonic spur | Frequency |
|---|---:|---:|
| Native | approximately -8.80 dBFS | 15041.02 Hz |
| 8x | approximately -48.86 dBFS | 21451.17 Hz |
| 16x | approximately -63.64 dBFS | 9943.36 Hz |

The original post-downsampling hard ceiling clamp produced about -21 dBFS at
16x in this test. It was removed and replaced by a linked lookahead guard after
downsampling. The improvement shown above is measured, but neither 8x nor 16x
is alias-free under severe overload. The -100 dBFS proposed normal-level target
from the earlier audit has not been validated across its full matrix.

The limiter/clipper ceiling was tested at -6 dBFS in every quality/rate/channel
combination: maximum sample peak 0.5011872053 (within floating-point tolerance
of the specified ceiling). This does not establish true-peak compliance.

Raw logs and JSON are in `Validation`. `Tests/analyse_spurs.py` reproduces the
FFT summary from the native harness's float renders. The Windows runtime failure
log records the environment block; it is not a plugin-loading result.
