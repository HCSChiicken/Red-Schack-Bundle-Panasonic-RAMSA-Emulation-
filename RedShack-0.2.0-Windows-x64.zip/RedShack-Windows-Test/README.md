# Red Shack Console 0.2.0 — first test build

Two Windows x64 VST3 effects: **Red Shack Channel** and **Red Shack Master**.
The hardware-style UI is implemented with live, automatable controls. The
channel dynamics section is named **Compressor**. The Master adds selectable
Soft Clip / Limit output dynamics. This build is for listening and host testing.

**This is not a validated component-accurate WR-T820B emulation.** The earlier
audit identified unresolved circuits. This alpha makes the controls and audio
processing executable while keeping those limitations explicit. See
`MODEL-STATUS.md` before drawing conclusions about hardware accuracy.

## Install and test on Windows

1. Close your DAW. Extract `RedShack-0.2.0-Windows-x64.zip`.
2. Copy the entire `Red Shack Channel.vst3` and `Red Shack Master.vst3` folders
   from `VST3` to `C:\Program Files\Common Files\VST3`. Windows may request
   administrator permission for the copy. Keep each bundle's `Contents` folder.
3. Reopen your DAW and rescan VST3 plugins. Names are **Red Shack Channel** and
   **Red Shack Master**, manufacturer **Vigilante Stylez**.

In FL Studio, scan with **Options → Manage plugins → Find installed plugins**.
Place Channel on individual tracks and Master on the stereo mix bus. The DAW
does the track summing; the Master models processing on the resulting stereo
signal. A stereo Channel represents linked audio lanes.

Start around **-18 dBFS sample peaks** on each input, trim/faders at 0 dB, EQ
flat, dynamics bypassed, noise off, Native quality. This is a provisional
calibration, not automatic level matching. Increase level/trim to investigate
overload. Master drive is after its console fader/output stage.

Both dynamics processors are bypassed by default. Channel compressor IN
engages post-EQ/pre-fader processing. Master IN engages its final output
dynamics. The ON buttons mute/unmute, using a short ramp.

## Controls

| Channel | Master |
|---|---|
| MIC / LINE / TAPE and ±20 dB trim | Linked L/R fader |
| MIC/LINE polarity; Tape ignores polarity | Left/right VU and output peak meters |
| 80 Hz, 18 dB/oct HPF | Pre-fader sum peak indicators |
| Low swept shelf, mid/high swept peaks | Soft Clip / Limit mode |
| Three concentric frequency/gain controls | Drive: 0–24 dB |
| EQ enable, fader, ON | Ceiling: -12–0 dBFS **sample peak** |
| Compressor threshold, makeup, ratio | Limiter release: 10–1000 ms or AUTO |
| Attack: .1/.3/1/3/10/30 ms; fixed/AUTO release | Dynamics IN and reduction meter |

For concentric EQ controls, drag the **outer cyan ring for frequency** and
the **inner dark knob for gain**. Numeric boxes can be edited. Shift gives
fine control; double-click returns a knob/fader to its default.

Soft Clip is a continuous, linear-below-knee transfer in the selected
oversampled domain. A stereo-linked 3 ms lookahead guard after downsampling
contains resampler overshoot. LIMIT uses the lookahead stage directly. RELEASE
is disabled while AUTO is on and in Soft Clip mode. This is a **sample-peak**
limiter; intersample/codec peaks are not guaranteed. Soft Clip also uses its
own fixed guard recovery rather than the disabled release knob.

The compressor intentionally rectifies the **signed L+R sum**. Anti-phase
stereo content can cancel in its detector. The limiter links using the larger
absolute L/R peak instead, preserving stereo balance without cancellation.

## Quality, noise, latency and state

- Native / 8x / 16x cover the console/Channel processing and soft clipper.
  The final limiter/guard runs at host rate, after downsampling.
- Quality and noise broadcasts work across both Windows plugin types **in
  the same host process**. Bridged/isolated plugin processes are separate.
  Other projects running in that process share the settings too.
- New instances adopt the process setting. Saved instances retain their
  settings; if restored settings conflict, the last restored instance wins.
  GUI synchronisation uses the message thread; audio reads shared memory.
- Native is the initial setting. Noise is initially off. Noise is a provisional
  independently seeded generator, not calibrated WR-T820B EIN. Seeds are saved.
- Latency is constant across quality modes, including processor bypass. At
  48 kHz: Channel **67 samples**, Master **211 samples**. Master includes 3 ms
  lookahead. The host receives latency for compensation. New quality paths
  warm up before a 10 ms crossfade; CPU rises briefly during a switch.
- Controls and global choices are saved in host state. Resizing is supported;
  editor size itself is not saved in this alpha.

## What was checked

`Validation` contains the actual DSP/integration results and snapshots of the
implemented GUI. Tests include four sample rates, mono/stereo buses, Native/8x/
16x switching, nonstandard host block sizes, finite output at extreme settings,
compressor static ratios, ceiling enforcement, silence with noise off, state
recall and no audio-thread allocations. See `VALIDATION.md` for final outcomes.

The Windows x64 binaries are cross-compiled with MinGW. They have been inspected
for architecture, VST3 exports and imported DLLs. **A Windows DAW scan, live
Windows GUI, bridged instances and real-session rendering remain untested.**
Wine could not start because this environment blocks its local IPC sockets.
The companion native VST3 build is used for interface-level checks.

## Build from source

The source archive includes JUCE 7.0.12 and font assets/licenses. With CMake
3.22+, Visual Studio 2022 C++ tools and a Windows SDK:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
```

Result bundles are under `build/RedShackChannel_artefacts/Release/VST3` and
`build/RedShackMaster_artefacts/Release/VST3`. The Windows host smoke test
initialises, processes, saves/restores state and attaches both VST3 editors.

Linux cross-build command (MinGW installed):

```bash
cmake -S . -B build-win -G Ninja -DCMAKE_TOOLCHAIN_FILE=mingw-toolchain.cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build-win --parallel 2
```

Native QA is enabled with `-DREDSHACK_BUILD_QA=ON`; run the `PluginQA` executable
with an output directory and a working X11 display. GNU/Linux VST3 binaries are
development counterparts, not included in the Windows test download.

Original application code is supplied under GPL-3.0-or-later for this test
distribution, with corresponding source included. JUCE, VST3 SDK and fonts
retain their notices. No Panasonic/RAMSA/SSL corporate logos are used.
