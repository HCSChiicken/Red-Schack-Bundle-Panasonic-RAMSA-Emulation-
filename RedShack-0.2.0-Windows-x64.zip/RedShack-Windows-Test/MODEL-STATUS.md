# Model status — 0.2.0 test build

The plugin is a functional sound/UI prototype. It does **not** complete the G1/G2
reference gates from the 0.1 circuit audit. Working software and passing stability
tests do not establish that it sounds identical to the physical console.

| Region | Implemented | Accuracy boundary |
|---|---|---|
| LINE buffer | Unity-normalised ideal IC6B R71=9.09k/R72=1k/C62=33p transfer, bilinear discretisation | Receiver, trim loading and finite op-amp model not derived |
| TAPE buffer | Unity-normalised ideal R77=20k/R76=2k/C65=33p transfer | Complete coupling/trim networks not traced |
| MIC | Normalised buffered input with trim | Discrete differential preamp and actual gain/noise/headroom not implemented |
| Polarity | MIC/LINE inversion; TAPE unaffected | Functional routing semantics, not phase-stage transistor model |
| HPF | Third-order 80 Hz Butterworth spec surrogate | Earlier candidate component network remains unresolved; **not** a netlist-derived HPF |
| EQ | Low shelf, mid/high peaks; manual ranges; ±15 dB; fixed non-exposed Q | Cookbook biquads with high Q=.8 / mid Q=1, **not** circuit-derived pot/loading/Q laws. Low nominal ±12 versus maximum ±15 remains an accuracy issue |
| Summing pair | Two unity-normalised 22k/47p ideal cells derived in 0.1 | DAW sum adapter, bus population/loading remain provisional |
| Driver | Normalised one-pole feedback-capacitance equivalent | Complete output driver/coupling/jack load not transcribed |
| Amplifier overload | Piecewise polynomial finite-swing surrogate; linear below 80% rail | No measured THD spectrum, slew/recovery or semiconductor fit. MIC/LINE/TAPE do not yet have verified independent headroom |
| Noise | Independent per-lane uniform white noise, before EQ; sample-rate-scaled PSD | Provisional -108 dB reference; not factory EIN/output noise, no hum/crosstalk simulation |
| Compressor | Rectified signed stereo sum; dB-domain gain-tracking feedback; 2/4/10; two-branch AUTO approximation | Control algorithm is original simplified code; no DBX/THAT device, TL074 rectifier, ratio-offset or detector circuit validation |
| Soft clipper | Piecewise cubic, continuous value/slope; flat below 75% ceiling | New product feature, not historical RAMSA hardware |
| Limiter/guard | Stereo-linked sliding-maximum lookahead; instant anticipation; fixed/adaptive release | New sample-peak product feature; host-rate gain control, not a true-peak/codec limiter |
| Meters | Input/output peak hold/recovery, RMS-derived nominal VU, dynamics GR | Software approximation; VU calibration provisional, no hardware detector/load model |

The adapter convention uses -18 dBFS sample-peak sine as nominal 0 VU. It maps
the master swing estimate to approximately -2 dBFS sample peak. Front-end paths
are normalised to unity at neutral controls, rather than exposing the physical
console's 84 dB maximum microphone gain. The DAW remains the source and summing
environment. These are product assumptions, not new hardware findings.

The source schematic for the added compressor is the Gyraf Audio mixbus clone
revision 9 (June 2013), previously supplied by Roland. Its reference explains
the gain-tracking detector and signed sidechain sum; this build implements a
simplified algorithm and does not claim circuit equivalence. User-facing controls
are named **Compressor**. The schematic is not redistributed in this package.

Future accuracy work: trace loaded EQ/HPF/trim networks, obtain an intact level
diagram, derive full driver and jack transfer, fit verified semiconductor models,
calibrate noise with stated weighting/load, validate the compressor timing and
ratio networks, and compare against a physical desk/reference simulation. The
manual's complete factory response, THD, EIN, CMRR and crosstalk fixtures have
not been reproduced by this alpha. Published maxima are not measured matches.

References are the user's supplied WR-T820B service manual and the preserved
0.1 audit. Source hashes:

- Manual: `7bbd8314bdb843a44c83358b91fe664e334112f5edcd593db8410ead1d50931a`
- Compressor drawing: `a4ae02ef4f725581dd66134b8b42a97060619ece6801d3104a49e43186b57c31`
- JUCE 7.0.12 archive: `94e3b35e1990cd67f59736bb5e1eff1cfd9590b16fea82696f309a8f59452434`
